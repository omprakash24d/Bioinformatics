import my_mod
print('Table from module')
my_mod.table(12)

print('###############################')
#print(mod.my_mod.codon_table['ATG'])

#x_met = mod.my_mod.codon_table['ATG']
#print('x_met = ',x_met)
def table (num): 
    for i in range (1,11,1):
        #print (num," * ", i,'=',num*i)
        pass
        
 
##print('Table from main program')
#table(20)

#Reuse
#Namespace