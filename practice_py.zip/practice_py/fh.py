import func_table
func_table.table(12)
fin = open('C:/Users/user/Documents/practice_py/aa/1bom.pdb','rt')
for fline in fin:
	#print(fline)
    pass
    

