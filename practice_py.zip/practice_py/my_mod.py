def table (num): 
    for i in range (1,11,1):
        print (num," * ", i,'=',num*i)

#table(3)
codon_table = {'ATG' : 'Met', 'TAA' : '*'}
#print(codon_table['ATG'])
