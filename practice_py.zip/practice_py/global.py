#x = 4
def ld():
	#global x
	x = 16
	print('Inside def = ',x)
ld()
print(x)
#x = 10
#print(x)